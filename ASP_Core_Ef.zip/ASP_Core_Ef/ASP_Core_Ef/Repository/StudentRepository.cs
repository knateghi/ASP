﻿using ASP_Core_Ef.Services;
using ASP_Core_EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASP_Core_Ef.Repository
{
    public class StudentRepository:IStudent
    {
        private DB_Context db;
        public StudentRepository(DB_Context _db)
        {
            db = _db;
        }
        public IEnumerable<Student> GetStudents => db.Students;

        public Student GetStudent(int? Id)
        {
            Student dbEntity=db.Students.Find(Id);
            return dbEntity;
        }
        public void Add(Student _Student)
        {
            db.Students.Add(_Student);
            db.SaveChanges();
        }
        public void Remove(int? Id)
        {
            Student dbEntity=db.Students.Find(Id);
            db.Students.Remove(dbEntity);
            db.SaveChanges();
        }
    }
}
