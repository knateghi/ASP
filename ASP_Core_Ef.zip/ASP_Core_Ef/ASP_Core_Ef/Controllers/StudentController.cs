﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASP_Core_Ef.Services;
using ASP_Core_EF.Models;
using Microsoft.AspNetCore.Mvc;

namespace ASP_Core_Ef.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudent Student;
        public StudentController(IStudent _Student)
        {
            Student = _Student;
        }
        public IActionResult Index()
        {
            return View(Student.GetStudents);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student model)
        {
            if (ModelState.IsValid)
            {
                Student.Add(model);
                return RedirectToAction("Index");
            }
            return View(model);
        }
       public IActionResult Delete(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            Student model=Student.GetStudent(Id);
            return View(model);
        }
        [HttpPost,ActionName("Delete")]
        public IActionResult DeleteConfirm(int? Id)
        {
            Student.Remove(Id);
            return RedirectToAction("Index");
        }
    }
}