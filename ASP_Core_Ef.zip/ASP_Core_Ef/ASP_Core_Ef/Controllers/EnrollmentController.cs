﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASP_Core_EF.Models;
using ASP_Core_EF.Services;
using Microsoft.AspNetCore.Mvc;

namespace ASP_Core_Ef.Controllers
{
    public class EnrollmentController : Controller
    {
        private readonly IEnrollment Enrollment;
        public EnrollmentController(IEnrollment _Enrollment)
        {
            Enrollment = _Enrollment;
        }
        public IActionResult Index()
        {
            return View(Enrollment.GetEnrollments);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Enrollment model)
        {
            if (ModelState.IsValid)
            {
                Enrollment.Add(model);
                return RedirectToAction("Index");
            }
            return View(model);
        }
        public IActionResult Delete(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
           
                Enrollment model = Enrollment.GetEnrollment(Id);
                return View(model);
            
        }
        [HttpPost,ActionName("Delete")]
        public IActionResult DeleteConfirm(int? Id)
        {
            Enrollment.Remove(Id);
            return RedirectToAction("Index");
        }
    }
}